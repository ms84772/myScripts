# Aria White List Lambdas
Back-end Lambdas for aria white list. 
Service is responsible for:
- updating white list table when S3 bucket with white list emails is changed
- sending notifications via email
- providing API for checking whether user email was added into the white list

# Architecture
![alt text](./img/architecture.png)

# Sequence Diagrams
- [Add wait list email](./sd/AddWaitlistEmail.puml)
- [Bind user details](./sd/BindUserDetails.puml)
- [Check email](./sd/CheckEmail.puml)
- [Handle white list insert](./sd/HandleWhitelistInsert.puml)
- [Resend invitation](./sd/ResendInvitation.puml)

# Run locally
```serverless invoke local -f <function_name>```

# Run tests
```jest --bail --coverage```
or
```npm test```

# Run static code analysis
##Configure 

- Run ```npm install --save-dev prettier```
- Run ```npm install --save-dev eslint-plugin-prettier```
- Run ```npm install --save-dev eslint-config-prettier```
- Configure your IDE for code format

##Run
```eslint . --ext .ts```
or
```npm lint```
