interface Person {
    email?: string
    firstName?: string
    lastName?: string
    associatePin?: string
    onboarded?: boolean
    onboarded_at?: string
}

export interface IWhiteListDetails extends Person {
    accountId?: string
    cmdId?: string
}

export interface IWaitListEmail extends Person {
    createdAt?: string
    phoneNumber?: string
}

export interface ICsvEntry {
    email: string
    UCA_ID?: string
    cmd_id?: string
    first_name?: string
    last_name?: string
    associatePin?: string
}

export const csvEntryKeys: Array<keyof ICsvEntry> = ['email', 'UCA_ID', 'cmd_id', 'first_name', 'last_name']

export interface Authentication {
    principalId?: string
    sub?: string
    email?: string
    brand?: string
}

export interface PlatinumChatInfo {
    userInfo?: PlatinumChatUserInfo
    location?: string
    chatOption?: string
}

export interface PlatinumChatUserInfo {
    given_name?: string
    family_name?: string
    phone_number?: string
    email?: string
    ucaId?: string
}
