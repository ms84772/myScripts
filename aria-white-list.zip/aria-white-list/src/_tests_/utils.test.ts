import { toShortDate, removeEmptyValues } from '../utils'

describe('utils test', () => {
    it('should convert date to short string date', () => {
        expect(toShortDate(new Date())).toHaveLength(10)
    })
    it('should remove empty values from object', () => {
        const obj = { test: null, test2: undefined, test3: '', test4: true }
        expect(removeEmptyValues(obj)).toEqual({ test4: true })
    })
})
