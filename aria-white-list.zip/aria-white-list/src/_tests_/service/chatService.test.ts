import AWS from 'aws-sdk'
import jwt_decode from 'jwt-decode'
import * as chatService from '../../service/chatService'
import sinon from 'sinon'
import { BusinessError } from '@nmg/osp-backend-utils/types'

const lambdaStub = sinon.stub(AWS, 'Lambda')

describe('get all appointments test', () => {
    let getAssociateStatusLambda

    afterEach(() => {
        sinon.reset()
    })

    it('should get and AssociateStatus', async () => {
        getAssociateStatusLambda = {
            invoke: sinon.stub().returnsThis(),
            promise: sinon.stub().resolves({
                StatusCode: '200',
                Payload: JSON.stringify({
                    body: JSON.stringify({ getAssociateStatus: 'ONLINE' }),
                }),
            }),
        }
        lambdaStub.callsFake(() => getAssociateStatusLambda)

        const result = await chatService.getAssociateStatusByPin('10001')
        expect(result).toEqual({ getAssociateStatus: 'ONLINE' })
    })
    it('should throw error getAssociateStatusLambda status code is not 200', async () => {
        getAssociateStatusLambda = {
            invoke: sinon.stub().returnsThis(),
            promise: sinon.stub().resolves({
                StatusCode: '400',
                Payload: JSON.stringify({
                    body: JSON.stringify('Unexpected error'),
                }),
            }),
        }
        lambdaStub.callsFake(() => getAssociateStatusLambda)

        await expect(chatService.getAssociateStatusByPin('10001')).rejects.toThrow(
            new BusinessError(400, 'Unexpected error'),
        )
    })
    it('should throw error getAssociateStatusLambda payload status code is not 200', async () => {
        getAssociateStatusLambda = {
            invoke: sinon.stub().returnsThis(),
            promise: sinon.stub().resolves({
                StatusCode: '200',
                Payload: JSON.stringify({
                    statusCode: '400',
                    body: JSON.stringify('Unexpected error'),
                }),
            }),
        }
        lambdaStub.callsFake(() => getAssociateStatusLambda)

        await expect(chatService.getAssociateStatusByPin('2002')).rejects.toThrow(
            new BusinessError(400, 'Unexpected error'),
        )
    })
})

describe('chat service test', () => {
    it('should get chat token', async () => {
        const token = await chatService.getTwilioToken('abcs')
        const { grants, iss, sub } = jwt_decode(token)
        expect({ grants, iss, sub }).toEqual({
            grants: { identity: 'abcs', chat: { service_sid: '789' } },
            iss: '324',
            sub: '123',
        })
    })
    it('should get platinum chat token', async () => {
        const token = await chatService.getTwilioPlatinumChatToken('abcs')
        const { grants, iss, sub } = jwt_decode(token)
        expect({ grants, iss, sub }).toEqual({
            grants: { identity: 'abcs', chat: { service_sid: 'platinumServiceSid' } },
            iss: '123',
            sub: 'platinumAccountSid',
        })
    })
})
