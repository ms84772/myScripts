import sinon from 'sinon'
import * as inviteStorage from '../../storage/invite'
import { Invite } from '../../storage/invite'
import * as emailService from '../../service/emailService'
import { getForDate, markValidated, resendForDate, sendFirstInvites } from '../../service/inviteService'

const updateInvite = sinon.stub(inviteStorage, 'update')
const getInvites = sinon.stub(inviteStorage, 'getInvites')
const sendInvitationEmail = sinon.stub(emailService, 'sendInvitationEmail')

describe('invite service test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should mark validated if no error occurred', async () => {
        updateInvite.resolves()
        const email = 'one@mail.com'
        await markValidated(email)
        expect(updateInvite.getCall(0).args[0]).toEqual(email)
    })
    it('should not mark validated if error occurred', async () => {
        updateInvite.rejects(new Error('Unexpected error'))
        const email = 'one@mail.com'
        await expect(markValidated(email)).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should get invites by date', async () => {
        let expected = [{ email: 'one@mail', validated: 'false', sent_at: '2021-02-26' }]
        getInvites.resolves(expected)
        const actual = await getForDate('2021-02-26', 1)
        expect(actual).toStrictEqual(expected)
        expect(getInvites.getCalls().length).toEqual(1)
    })
    it('should not get invites by date if error occurred', async () => {
        getInvites.rejects(new Error('Unexpected error'))
        await expect(getForDate('2021-02-26', 1)).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should resend invites for period', async () => {
        const date = '2021-02-26'
        const invites = [new Invite('one@mail.com', date), new Invite('two@mail.com', date)]

        updateInvite.resolves()
        sendInvitationEmail.resolves()

        getInvites.resolves(invites)

        await resendForDate(date)

        sinon.assert.callCount(updateInvite, invites.length)
        sinon.assert.callCount(sendInvitationEmail, invites.length)
        sinon.assert.calledOnce(getInvites)
    })
    it('should not resend invite for 2nd period if resend throws error', async () => {
        const date = '2021-02-26'
        const invites = [new Invite('one@mail.com', date), new Invite('two@mail.com', date)]

        updateInvite.onFirstCall().resolves()
        updateInvite.onSecondCall().rejects(new Error('Error occurred during save invite'))

        getInvites.resolves(invites)

        await expect(resendForDate(date)).resolves.not.toThrow()

        sinon.assert.callCount(updateInvite, invites.length)
        sinon.assert.callCount(sendInvitationEmail, invites.length)
        sinon.assert.calledOnce(getInvites)
    })
    it('should send first invites', async () => {
        const invites: Invite[] = [{ email: '1' }, { email: '2' }, { email: '3' }]
        getInvites.resolves(invites)
        await sendFirstInvites()
        sinon.assert.callCount(sendInvitationEmail, invites.length)
        sinon.assert.callCount(updateInvite, invites.length)
    })
})
