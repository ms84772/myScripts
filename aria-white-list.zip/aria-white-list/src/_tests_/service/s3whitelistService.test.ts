import sinon from 'sinon'
import * as storage from '../../storage/whiteListDetails'
import { fetchS3Whitelist } from '../../service/S3whitelistService'
import * as AWSMock from 'aws-sdk-mock'
import AWS from 'aws-sdk'
import fs from 'fs'
import path from 'path'

const expected = [
    {
        uca_id: 'werefoxx@gmail.com',
        cmd_id: '12',
        first_name: 'Oleg',
        last_name: 'Bilka',
        email: 'werefoxx@gmail.com',
    },
    {
        uca_id: 'oleg_b@gmail.com',
        cmd_id: '12',
        first_name: 'Alex',
        last_name: 'Banton',
        email: 'test@gmail.com',
    },
]

describe('s3whiteListService test', () => {
    let explicitTime, copySpy, deleteSpy, uploadSpy, update, clock

    beforeEach(() => {
        explicitTime = Date.now()
        clock = sinon.useFakeTimers(explicitTime)
        deleteSpy = sinon.stub().resolves()
        copySpy = sinon.stub().resolves()
        uploadSpy = sinon.stub().resolves()
        update = sinon.stub(storage, 'saveWhitelist')
    })

    afterEach(() => {
        sinon.restore()
        AWSMock.restore()
        clock.restore()
    })

    it('should move file with invalid entries to the failed folder, saving valid to the whitelist', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'getObject', {
            Body: fs.readFileSync(path.resolve(__dirname, '../mocks/whitelists/testfailed.csv')),
        })
        AWSMock.mock('S3', 'copyObject', copySpy)
        AWSMock.mock('S3', 'deleteObject', deleteSpy)
        AWSMock.mock('S3', 'upload', uploadSpy)
        await expect(fetchS3Whitelist('test-bucket', 'uploads/test-file')).resolves.toEqual(undefined)
        expect(copySpy).toBeCalledWith({
            Bucket: 'aria-whitelist-invites',
            CopySource: '/test-bucket/uploads/test-file',
            Key: `processed/${explicitTime}-test-file`,
        })
        expect(deleteSpy).toBeCalledWith({
            Bucket: 'test-bucket',
            Key: 'uploads/test-file',
        })
        expect(update).toBeCalledWith(expected.slice(1))
    })

    it('should not delete file if copy from another account', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'upload', uploadSpy)
        AWSMock.mock('S3', 'getObject', {
            Body: fs.readFileSync(path.resolve(__dirname, '../mocks/whitelists/test.csv')),
        })
        AWSMock.mock('S3', 'copyObject', copySpy)
        AWSMock.mock('S3', 'deleteObject', deleteSpy)
        await fetchS3Whitelist('test-bucket', 'uploads/test-file', false)
        expect(deleteSpy).not.toBeCalled()
        AWSMock.restore()
    })

    it('should move invalid entries of the failed file', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'upload', uploadSpy)
        AWSMock.mock('S3', 'getObject', {
            Body: fs.readFileSync(path.resolve(__dirname, '../mocks/whitelists/noEmail.csv')),
        })
        AWSMock.mock('S3', 'copyObject', copySpy)
        AWSMock.mock('S3', 'deleteObject', deleteSpy)
        await expect(fetchS3Whitelist('test-bucket', 'uploads/test-file')).resolves.toEqual(undefined)
        expect(copySpy).toBeCalledWith({
            Bucket: 'aria-whitelist-invites',
            CopySource: '/test-bucket/uploads/test-file',
            Key: `processed/${explicitTime}-test-file`,
        })
        expect(deleteSpy).toBeCalledWith({
            Bucket: 'test-bucket',
            Key: 'uploads/test-file',
        })
        expect(update).not.toHaveBeenCalled()
    })

    it('should save valid records, and upload failed records to the failed folder', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'upload', uploadSpy)
        AWSMock.mock('S3', 'getObject', {
            Body: fs.readFileSync(path.resolve(__dirname, '../mocks/whitelists/invalidFile.csv')),
        })
        AWSMock.mock('S3', 'copyObject', copySpy)
        AWSMock.mock('S3', 'deleteObject', deleteSpy)
        await expect(fetchS3Whitelist('test-bucket', 'uploads/test-file')).resolves.toEqual(undefined)
        expect(copySpy).toBeCalledWith({
            Bucket: 'aria-whitelist-invites',
            CopySource: '/test-bucket/uploads/test-file',
            Key: `processed/${explicitTime}-test-file`,
        })
        expect(deleteSpy).toBeCalledWith({
            Bucket: 'test-bucket',
            Key: 'uploads/test-file',
        })
        expect(update).not.toHaveBeenCalled()
    })

    it('should parse and save the whitelist', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'getObject', {
            Body: fs.readFileSync(path.resolve(__dirname, '../mocks/whitelists/test.csv')),
        })
        AWSMock.mock('S3', 'copyObject', copySpy)
        AWSMock.mock('S3', 'deleteObject', deleteSpy)
        await fetchS3Whitelist('test-bucket', 'uploads/test-file')
        expect(copySpy).toBeCalledWith({
            Bucket: 'aria-whitelist-invites',
            CopySource: '/test-bucket/uploads/test-file',
            Key: `processed/${explicitTime}-test-file`,
        })
        expect(copySpy).toBeCalledWith({
            Bucket: 'aria-whitelist-invites',
            CopySource: '/test-bucket/uploads/test-file',
            Key: `stanleyApp/${explicitTime}-test-file`,
        })
        expect(deleteSpy).toBeCalledWith({
            Bucket: 'test-bucket',
            Key: 'uploads/test-file',
        })
        expect(update).toBeCalledWith(expected)
        AWSMock.restore()
    })

    it('should throw an error while getting a whitelist', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('S3', 'getObject', function (params, callback) {
            callback(new Error('oops'), params)
        })
        expect(update).not.toBeCalled()
        return expect(fetchS3Whitelist('test-bucket', 'test-file')).rejects.toThrow(new Error('oops'))
    })
})
