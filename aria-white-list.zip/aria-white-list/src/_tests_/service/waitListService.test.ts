import sinon from 'sinon'
import { IWaitListEmail } from '../../types'
import { emailExists, removeFromWaitList, saveToWaitList } from '../../service/waitListService'
import { toShortDate } from '../../utils'
import * as storage from '../../storage/waitListEmail'
import { WaitListEmail } from '../../storage/waitListEmail'

const waitListEmailDto: IWaitListEmail = {
    email: 'one@mail.com',
    firstName: 'One',
    lastName: 'Two',
}
describe('waitListService test', () => {
    const saveStub = sinon.stub(storage, 'put')
    const batchRemoveStub = sinon.stub(storage, 'batchRemove')
    const getStub = sinon.stub(storage, 'get')

    afterEach(() => {
        sinon.reset()
    })
    it('should save wait list email', async () => {
        const waitListEmail: WaitListEmail = {
            email: 'one@mail.com',
            first_name: 'One',
            last_name: 'Two',
            created_at: toShortDate(new Date()),
        }
        saveStub.resolves(waitListEmail)
        const saved = await saveToWaitList(waitListEmailDto)
        expect(saved).toEqual({
            createdAt: toShortDate(new Date()),
            ...waitListEmailDto,
        })
        sinon.assert.calledOnce(saveStub)
    })
    it('should throw error if save wait list email failed', async () => {
        saveStub.rejects(new Error('Unexpected error'))
        await expect(saveToWaitList(waitListEmailDto)).rejects.toThrow(new Error('Unexpected error'))
        sinon.assert.calledOnce(saveStub)
    })
    it('should remove record from db', async () => {
        await removeFromWaitList([{ email: 'one@mail.com', uca_id: '123' }])

        sinon.assert.calledOnce(batchRemoveStub)
        sinon.assert.calledWith(batchRemoveStub, ['one@mail.com'])
    })
    it('should return true if email in wait list', async () => {
        getStub.resolves({ email: 'one@mail.com' })
        expect(await emailExists('one@mail.com')).toBeTruthy()
    })
    it('should return true if email in wait list', async () => {
        getStub.resolves(undefined)
        expect(await emailExists('one@mail.com')).toBeFalsy()
    })
})
