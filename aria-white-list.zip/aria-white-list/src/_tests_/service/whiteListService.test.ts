import sinon from 'sinon'
import * as whiteListStorage from '../../storage/whiteListDetails'
import * as inviteStorage from '../../storage/invite'
import * as invitesService from '../../service/inviteService'
import * as emailService from '../../service/emailService'
import {
    bindEmailAndAccountId,
    getDetailsByUcaId,
    getWhiteListDetails,
    sendEmail,
    sendToHistoryTopic,
} from '../../service/whiteListService'
import { property } from '@nmg/osp-backend-utils/config'
import { equals } from '@aws/dynamodb-expressions/build/ConditionExpression'
import AWS from 'aws-sdk'
import * as AWSMock from 'aws-sdk-mock'

const getByEmail = sinon.stub(whiteListStorage, 'getByEmail')
const markValidated = sinon.stub(invitesService, 'markValidated')
const update = sinon.stub(whiteListStorage, 'update')
const sendInvitationEmail = sinon.stub(emailService, 'sendInvitationEmail')
const saveInvite = sinon.stub(inviteStorage, 'save')
const getByIndex = sinon.stub(whiteListStorage, 'getByIndex')
const snsStub = sinon.stub()

describe('whiteListService test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should get details by email and update invite validated', async () => {
        const expected = {
            email: 'one@gmail.com',
            uca_id: '111',
            cmd_id: '222',
            first_name: 'Will',
            last_name: 'Smith',
        }

        await getByEmail.resolves(expected)
        await markValidated.resolves()

        const actual = await getWhiteListDetails(expected.email)

        expect(actual.email).toEqual(expected.email)
        expect(actual.accountId).toEqual(expected.uca_id)
        expect(actual.cmdId).toEqual(expected.cmd_id)
        expect(actual.firstName).toEqual(expected.first_name)
        expect(actual.lastName).toEqual(expected.last_name)
        expect(markValidated.getCalls().length).toEqual(1)
    })
    it('should not get details by email if user not found', async () => {
        await getByEmail.resolves(undefined)
        const actual = await getWhiteListDetails('one@gmail.com')
        expect(markValidated.getCalls().length).toEqual(0)
        expect(actual).toBeUndefined()
    })
    it('should not get details by email if unexpected error occurred in mapper during update', async () => {
        const request = {
            email: 'one@gmail.com',
            uca_id: '111',
            cmd_id: '222',
        }
        await getByEmail.resolves(request)
        markValidated.rejects(new Error('Unexpected error'))

        await expect(getWhiteListDetails(request.email)).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should bind email and account id', async () => {
        await update.resolves()
        await bindEmailAndAccountId('one@mail.com', '123')
    })
    it('should throw error when bind email and account id if unexpected error occurred in mapper', async () => {
        await update.rejects(new Error('Unexpected error'))
        await expect(bindEmailAndAccountId('one@mail.com', '123')).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should throw error when bind email and account id if unexpected error occurred in mapper', async () => {
        await update.rejects(new Error('Unexpected error'))
        await expect(bindEmailAndAccountId('one@mail.com', '123')).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should sendEmail for dynamodb white list event', async () => {
        await sendEmail({ email: 'one@mail.com', uca_id: '123' })

        sinon.assert.calledOnce(sendInvitationEmail)
        sinon.assert.calledOnce(saveInvite)

        expect(sendInvitationEmail.getCall(0).args[0]).toEqual('one@mail.com')
        expect(saveInvite.getCall(0).args[0].email).toEqual('one@mail.com')
    })
    it('should not throw error while sendEmail for dynamodb white list event if sendInvite fails', async () => {
        sendInvitationEmail.rejects(new Error('Error during send invite'))

        await expect(sendEmail({ email: 'one@mail.com', uca_id: '123' })).resolves.not.toThrow()

        sinon.assert.calledOnce(sendInvitationEmail)
        sinon.assert.notCalled(saveInvite)

        expect(sendInvitationEmail.getCall(0).args[0]).toEqual('one@mail.com')
    })
    it('should get details by ucaId', async () => {
        const expected = {
            email: 'one@gmail.com',
            uca_id: '111',
            cmd_id: '222',
            first_name: 'Will',
            last_name: 'Smith',
        }

        getByIndex.resolves([expected])

        const actual = await getDetailsByUcaId('111')

        expect(actual.email).toEqual(expected.email)
        expect(actual.accountId).toEqual(expected.uca_id)
        expect(actual.cmdId).toEqual(expected.cmd_id)
        expect(actual.firstName).toEqual(expected.first_name)
        expect(actual.lastName).toEqual(expected.last_name)

        sinon.assert.calledWith(getByIndex, property('UCA_ID_INDEX'), {
            ...equals('111'),
            subject: 'uca_id',
        })
    })
    it('should not get details by ucaId if not found', async () => {
        getByIndex.resolves(undefined)

        const actual = await getDetailsByUcaId('111')

        expect(actual).toBeUndefined()
    })
    it('should throw error if getByIndex throws error', async () => {
        getByIndex.rejects(new Error('Unexpected error'))

        await expect(getDetailsByUcaId('111')).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should send message to white list history sns topic', async () => {
        AWSMock.setSDKInstance(AWS)
        AWSMock.mock('SNS', 'publish', snsStub)
        snsStub.resolves()

        const details = [
            { email: 'one@mail.com', uca_id: '123' },
            { email: 'two@mail.com', uca_id: '456' },
        ]
        await sendToHistoryTopic(details)

        sinon.assert.calledWith(snsStub, {
            TopicArn: 'test-sns',
            Subject: 'Stanley whitelist emails',
            Message: JSON.stringify(details),
        })
    })
})
