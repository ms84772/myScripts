import AWS from 'aws-sdk'
import sinon from 'sinon'
import { sendInvitationEmail, sendWaitListConfirmation } from '../../service/emailService'
import { property } from '@nmg/osp-backend-utils/config'
import { Feature } from '@nmg/aria-backend-utils/optimizely/Feature'

const testEmail = 'test@mail.com'
const payload = { hello: 'world' }

describe('emailService test', () => {
    let sendEmailLambda
    const lambdaStub = sinon.stub(AWS, 'Lambda')
    const featureStub = sinon.stub(Feature, 'isEnabled')
    beforeEach(() => {
        sendEmailLambda = { invoke: sinon.stub().returnsThis(), promise: sinon.stub() }
    })
    afterEach(() => {
        sinon.reset()
    })
    it('should send email', async () => {
        lambdaStub.callsFake(() => sendEmailLambda)
        featureStub.resolves(true)
        await sendInvitationEmail(testEmail, payload)

        sinon.assert.calledOnce(sendEmailLambda.invoke)
        sinon.assert.calledWith(sendEmailLambda.invoke, {
            FunctionName: property('SEND_EMAIL_ARN'),
            InvocationType: 'RequestResponse',
            Payload: JSON.stringify({
                queryStringParameters: {
                    brand: 'NM',
                    templateId: 'invitation_template',
                },
                body: JSON.stringify({
                    subject: 'You have been invited to Stanley. The Neiman Marcus Lifestyle assistant.',
                    emailsTo: [testEmail],
                    payload: payload,
                }),
            }),
        })
    })
    it('should send "added to waitlist" e-mail', async () => {
        lambdaStub.callsFake(() => sendEmailLambda)
        featureStub.resolves(true)

        await sendWaitListConfirmation(testEmail)
        sinon.assert.calledOnce(sendEmailLambda.invoke)
        sinon.assert.calledWith(sendEmailLambda.invoke, {
            FunctionName: property('SEND_EMAIL_ARN'),
            InvocationType: 'RequestResponse',
            Payload: JSON.stringify({
                queryStringParameters: {
                    brand: 'NM',
                    templateId: 'waitlist_template',
                },
                body: JSON.stringify({
                    subject: 'YOU HAVE BEEN ADDED TO THE WAITLIST.',
                    emailsTo: [testEmail],
                }),
            }),
        })
    })
    it('should not fail if error occurred during send email invitation', async () => {
        sendEmailLambda = {
            invoke: sinon.stub().onFirstCall().throws().onSecondCall().returnsThis(),
            promise: sinon.stub(),
        }
        lambdaStub.onSecondCall().callsFake(() => sendEmailLambda)
        await expect(sendInvitationEmail(testEmail, payload)).resolves.not.toThrow()
    })
    it('should not fail if error occurred during send email wait list confirmation', async () => {
        sendEmailLambda = {
            invoke: sinon.stub().onFirstCall().throws().onSecondCall().returnsThis(),
            promise: sinon.stub(),
        }
        lambdaStub.onSecondCall().callsFake(() => sendEmailLambda)
        await expect(sendWaitListConfirmation(testEmail)).resolves.not.toThrow()
    })
})
