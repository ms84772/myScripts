import sinon from 'sinon'
import { handle as addWaitListEmail } from '../handlers/addWaitListEmail'
import { handle as bindUserDetails } from '../handlers/bindUserDetails'
import { handle as checkEmail } from '../handlers/checkEmail'
import { handle as loadS3WhiteList } from '../handlers/loadS3WhiteList'
import { handle as getWhiteListDetailsByUcaId } from '../handlers/getWhiteListDetailsByUcaId'
import { handle as handleWhiteListInsert } from '../handlers/handleWhiteListInsert'
import { handle as processCdpEvent } from '../handlers/processCdpEvent'
import { handle as resendInvites } from '../handlers/resendInvites'
import { handle as getChatToken } from '../handlers/getChatToken'
import { handle as setOnBoardedHandler } from '../handlers/setOnBoarded'
import { handle as getPlatinumChatToken } from '../handlers/getPlatinumChatToken'
import { handle as getAssociateStatus } from '../handlers/getAssociateStatus'
import * as whiteListService from '../service/whiteListService'
import * as waitListService from '../service/waitListService'
import * as emailService from '../service/emailService'
import * as inviteService from '../service/inviteService'
import * as chatService from '../service/chatService'
import * as S3whitelistService from '../service/S3whitelistService'
import { IWhiteListDetails } from '../types'
import {
    dataMapperIteratorMock,
    dynamoDbWhiteList,
    dynamoDbWhiteListEvents,
    getGatewayProxyEventMock,
} from './mocks/common'
import { toShortDate } from '../utils'
import { property } from '@nmg/osp-backend-utils/config'
import { getS3EventMock } from './mocks/s3'
import CDPWhiteListSQSEvent from './mocks/cdp/whiteListSQSEvent.json'
import CDPWhiteListS3Event from './mocks/cdp/whiteListS3Event.json'
import { S3Event, SQSEvent } from 'aws-lambda'
import { DataMapper as mapper } from '@aws/dynamodb-data-mapper/build/DataMapper'
import { Invite } from '../storage/invite'

const fetchS3Whitelist = sinon.stub(S3whitelistService, 'fetchS3Whitelist')
const getWhiteListDetails = sinon.stub(whiteListService, 'getWhiteListDetails')
const getAssociateStatusByPin = sinon.stub(chatService, 'getAssociateStatusByPin')
const bindEmailAndAccountId = sinon.stub(whiteListService, 'bindEmailAndAccountId')
const setOnBoarded = sinon.stub(whiteListService, 'setOnBoarded')
const getTwilioToken = sinon.stub(chatService, 'getTwilioToken')
const getTwilioPlatinumToken = sinon.stub(chatService, 'getTwilioPlatinumChatToken')
const sendEmail = sinon.stub(whiteListService, 'sendEmail')
const sendToHistoryTopic = sinon.stub(whiteListService, 'sendToHistoryTopic')
const removeFromWaitList = sinon.stub(waitListService, 'removeFromWaitList')
const getForDate = sinon.stub(inviteService, 'getForDate')
const resendForDate = sinon.stub(inviteService, 'resendForDate')
const saveInvites = sinon.stub(mapper.prototype, 'batchPut')
const getDetailsByUcaId = sinon.stub(whiteListService, 'getDetailsByUcaId')
const emailExistsStub = sinon.stub(waitListService, 'emailExists')
const saveToWaitListStub = sinon.stub(waitListService, 'saveToWaitList')
const sendWaitListConfirmationStub = sinon.stub(emailService, 'sendWaitListConfirmation')

describe('handler test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should throw error if email not exists in query params', async () => {
        const response = await checkEmail(getGatewayProxyEventMock())
        const body = JSON.parse(response.body) as Error

        expect(response.statusCode).toBe(400)
        expect(body.message).toEqual('Email parameter can not be empty')
    })
    it('should throw error if email not found', async () => {
        await getWhiteListDetails.resolves(undefined)

        const email = 'unknown@email.com'

        const response = await checkEmail(getGatewayProxyEventMock({ queryStringParameters: { email: email } }))
        const body = JSON.parse(response.body) as Error

        expect(response.statusCode).toBe(404)
        expect(body.message).toEqual(`User not found for email: ${email}`)
    })
    it('should throw error if email is empty', async () => {
        const response = await checkEmail(getGatewayProxyEventMock({ queryStringParameters: { email: ' ' } }))
        const body = JSON.parse(response.body) as Error

        expect(response.statusCode).toBe(400)
        expect(body.message).toEqual('Email parameter can not be empty')
    })
    it('should return email details from white list', async () => {
        const expectedResponse = {
            email: 'one@gmail.com',
            accountId: '111',
            cmdId: '222',
        }
        await getWhiteListDetails.resolves(expectedResponse)

        const response = await checkEmail(
            getGatewayProxyEventMock({
                queryStringParameters: { email: expectedResponse.email },
            }),
        )
        const body = JSON.parse(response.body) as IWhiteListDetails
        expect(body).toEqual(expectedResponse)
    })
    it('should return 500 if unexpected error occurred', async () => {
        const expectedResponse = {
            email: 'one@gmail.com',
            accountId: '111',
            cmdId: '222',
        }
        await getWhiteListDetails.rejects(new Error('Unexpected error'))

        const response = await checkEmail(
            getGatewayProxyEventMock({
                queryStringParameters: { email: expectedResponse.email },
            }),
        )
        expect(response.statusCode).toBe(500)
    })
    it('should get chat token', async () => {
        await getTwilioToken.resolves()
        const result = await getChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioToken.getCall(0).args).toEqual(['123'])
        expect(result.statusCode).toBe(200)
    })
    it('should throw error 400 getting token if authorizer ucaId not provided', async () => {
        await getTwilioToken.resolves()
        const result = await getChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: null,
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioToken).toHaveBeenCalledTimes(0)
        expect(result.statusCode).toBe(400)
    })
    it('should throw error 500 getting token on error', async () => {
        await getTwilioToken.rejects()
        const result = await getChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioToken).toHaveBeenCalledTimes(1)
        expect(result.statusCode).toBe(500)
    })
    it('should set onboarding flag', async () => {
        await setOnBoarded.resolves()
        const result = await setOnBoardedHandler(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(setOnBoarded.getCall(0).args).toEqual(['one@mail.com'])
        expect(result.statusCode).toBe(200)
    })
    it('should not set onboarding flag on unknown error', async () => {
        await setOnBoarded.rejects(new Error('Unexpected error'))
        const result = await setOnBoardedHandler(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(setOnBoarded.getCall(0).args).toEqual(['one@mail.com'])
        expect(result.statusCode).toBe(500)
    })
    it('should bind user details', async () => {
        await bindEmailAndAccountId.resolves()
        const result = await bindUserDetails(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(bindEmailAndAccountId.getCall(0).args).toEqual(['one@mail.com', '123'])
        expect(result.statusCode).toBe(200)
    })
    it('should not bind user details if unexpected error occurred', async () => {
        await bindEmailAndAccountId.rejects(new Error('Unexpected error'))
        const result = await bindUserDetails(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(bindEmailAndAccountId.getCall(0).args).toEqual(['one@mail.com', '123'])
        expect(result.statusCode).toBe(500)
    })
    it('should not bind user details if authorization parameter is invalid', async () => {
        const result = await bindUserDetails(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: null,
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(bindEmailAndAccountId.getCalls().length).toEqual(0)
        expect(result.statusCode).toBe(400)
    })
    it('should not handle white list insert for non INSERT event', async () => {
        const events = dynamoDbWhiteListEvents([
            dynamoDbWhiteList('MODIFY', { email: 'one@mail.com', uca_id: '123' }),
            dynamoDbWhiteList('REMOVE', { email: 'two@mail.com', uca_id: '456' }),
        ])

        await handleWhiteListInsert(events)

        sinon.assert.notCalled(sendEmail)
        sinon.assert.notCalled(sendToHistoryTopic)
        sinon.assert.notCalled(removeFromWaitList)
    })
    it('should handle white list insert for INSERT event', async () => {
        const events = dynamoDbWhiteListEvents([
            dynamoDbWhiteList('INSERT', { email: 'one@mail.com', uca_id: '123' }),
            dynamoDbWhiteList('INSERT', { email: 'two@mail.com', uca_id: '456' }),
        ])

        const details = [
            { email: 'one@mail.com', uca_id: '123' },
            { email: 'two@mail.com', uca_id: '456' },
        ]

        saveInvites.callsFake(() => dataMapperIteratorMock(details.map((detail) => new Invite(detail.email))))

        await handleWhiteListInsert(events)

        sinon.assert.notCalled(sendEmail)
        sinon.assert.calledOnce(saveInvites)

        sinon.assert.calledWith(sendToHistoryTopic, details)
    })
    it('should not fail if handle white list insert for INSERT event failed', async () => {
        const events = dynamoDbWhiteListEvents([
            dynamoDbWhiteList('INSERT', { email: 'one@mail.com', uca_id: '123' }),
            dynamoDbWhiteList('INSERT', { email: 'two@mail.com', uca_id: '456' }),
        ])

        sendEmail.rejects()

        await expect(handleWhiteListInsert(events)).resolves.not.toThrow()
    })
    it('should resend invites for date', async () => {
        getForDate.resolves()
        let date: Date

        date = new Date()
        date.setDate(date.getDate() - +property('RESEND_EMAILS_PERIOD_DAYS'))
        const dateStr = toShortDate(date)

        await resendInvites()

        sinon.assert.calledWith(resendForDate, dateStr)
        sinon.assert.calledOnce(resendForDate)
    }, 10000)
    it('should not fail while resend invites for date', async () => {
        resendForDate.rejects()
        await expect(resendInvites()).resolves.not.toThrow()
    })
    it('should return details from white list when get by ucaId', async () => {
        const expectedResponse = {
            email: 'one@gmail.com',
            accountId: '111',
            cmdId: '222',
        }
        await getDetailsByUcaId.resolves(expectedResponse)

        const result = await getWhiteListDetailsByUcaId({ ucaId: '111' })
        expect(result).toEqual(expectedResponse)
    })
    it('should return details from white list when get by ucaId with http proxy event', async () => {
        const expectedResponse = {
            email: 'one@gmail.com',
            accountId: '111',
            cmdId: '222',
        }
        await getDetailsByUcaId.resolves(expectedResponse)

        const result = await getWhiteListDetailsByUcaId(
            getGatewayProxyEventMock({
                body: JSON.stringify({
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                }),
            }),
        )
        expect(result.body).toEqual(JSON.stringify(expectedResponse))
        expect(result.statusCode).toEqual(200)
    })
    it('should throw error when get by ucaId if service failed to get details', async () => {
        await getDetailsByUcaId.rejects(new Error('Unexpected error'))
        await expect(getWhiteListDetailsByUcaId({ ucaId: '111' })).rejects.toThrow(new Error('Unexpected error'))
    })
})

describe('get platinum chat token test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should get platinum chat token', async () => {
        await getTwilioPlatinumToken.resolves()
        const result = await getPlatinumChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioPlatinumToken.getCall(0).args).toEqual(['123'])
        expect(result.statusCode).toBe(200)
    })
    it('should throw error 400 getting platinum token if authorizer ucaId not provided', async () => {
        await getTwilioPlatinumToken.resolves()
        const result = await getPlatinumChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: null,
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioPlatinumToken).toHaveBeenCalledTimes(0)
        expect(result.statusCode).toBe(400)
    })
    it('should throw error 500 getting platinum token on error', async () => {
        await getTwilioPlatinumToken.rejects()
        const result = await getPlatinumChatToken(
            getGatewayProxyEventMock({
                authorizer: {
                    email: 'one@mail.com',
                    sub: '123',
                    principalId: null,
                    brand: null,
                },
            }),
        )
        expect(getTwilioPlatinumToken).toHaveBeenCalledTimes(1)
        expect(result.statusCode).toBe(500)
    })
})

describe('getWhitelist handler test', () => {
    it('Should call fetchS3Whitelist with correct bucket and key params', async () => {
        await fetchS3Whitelist.resolves(undefined)
        await loadS3WhiteList(getS3EventMock())
        expect(fetchS3Whitelist).toBeCalledWith('my-bucket-name', 'object-key')
    })
})

describe('wait list email test', () => {
    const email = 'one@mail.com'
    const firstName = 'One'
    const lastName = 'Two'
    const phoneNumber = '+1-234-134'

    afterEach(() => {
        sinon.reset()
    })

    it('should add email to wait list and send email', async () => {
        emailExistsStub.resolves(false)
        const result = await addWaitListEmail(
            getGatewayProxyEventMock({
                body: JSON.stringify({
                    email: email,
                    firstName: firstName,
                    lastName: lastName,
                    phoneNumber: phoneNumber,
                }),
            }),
        )
        expect(result.statusCode).toBe(200)
        sinon.assert.calledOnce(emailExistsStub)
        sinon.assert.calledOnce(saveToWaitListStub)
        sinon.assert.calledWith(saveToWaitListStub, {
            email: email,
            firstName: firstName,
            lastName: lastName,
            phoneNumber: phoneNumber,
        })
        sinon.assert.calledOnce(sendWaitListConfirmationStub)
    })
    it('should return 409 if email already exists', async () => {
        emailExistsStub.resolves(true)
        const result = await addWaitListEmail(
            getGatewayProxyEventMock({
                body: JSON.stringify({
                    email: email,
                }),
            }),
        )
        const body = JSON.parse(result.body) as Error

        expect(result.statusCode).toBe(409)
        expect(body.message).toEqual(`Email ${email} already in wait list`)
        sinon.assert.calledOnce(emailExistsStub)
        sinon.assert.notCalled(saveToWaitListStub)
        sinon.assert.notCalled(sendWaitListConfirmationStub)
    })
    it('should return 400 if email is empty', async () => {
        const result = await addWaitListEmail(
            getGatewayProxyEventMock({
                body: JSON.stringify({
                    email: ' ',
                }),
            }),
        )
        const body = JSON.parse(result.body) as Error

        expect(result.statusCode).toBe(400)
        expect(body.message).toEqual('Email can not be empty')
        sinon.assert.notCalled(emailExistsStub)
        sinon.assert.notCalled(saveToWaitListStub)
        sinon.assert.notCalled(sendWaitListConfirmationStub)
    })
    it('should return 500 if unexpected error occurred', async () => {
        emailExistsStub.rejects(new Error('Unexpected error'))
        const result = await addWaitListEmail(
            getGatewayProxyEventMock({
                body: JSON.stringify({
                    email: email,
                }),
            }),
        )
        const body = JSON.parse(result.body) as Error

        expect(result.statusCode).toBe(500)
        expect(body.message).toEqual(`Error occurred during processing wait list email ${email}`)
        sinon.assert.calledOnce(emailExistsStub)
        sinon.assert.notCalled(saveToWaitListStub)
        sinon.assert.notCalled(sendWaitListConfirmationStub)
    })
})

describe('processCdpEvent test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should call getWhitelist for income SQSEvent', async () => {
        const sqsEvent: SQSEvent = (CDPWhiteListSQSEvent as unknown) as SQSEvent
        await fetchS3Whitelist.resolves(undefined)
        await processCdpEvent(sqsEvent)

        const s3Event: S3Event = (CDPWhiteListS3Event as unknown) as S3Event
        sinon.assert.calledWith(
            fetchS3Whitelist,
            s3Event.Records[0].s3.bucket.name,
            s3Event.Records[0].s3.object.key,
            false,
        )
    })
})

describe('getAssociateStatus handler test', () => {
    afterEach(() => {
        sinon.reset()
    })
    it('should get associate status', async () => {
        const expectedResponse = {
            getAssociateStatus: 'ONLINE',
        }
        await getAssociateStatusByPin.resolves(expectedResponse)

        const response = await getAssociateStatus(
            getGatewayProxyEventMock({
                pathParameters: { pin: '10001' },
            }),
        )
        const body = JSON.parse(response.body)
        expect(body).toEqual(expectedResponse)
    })
})
