import sinon from 'sinon'
import { DataMapper as mapper } from '@aws/dynamodb-data-mapper'
import { batchRemove, get, put, WaitListEmail } from '../../storage/waitListEmail'
import { dataMapperIteratorMock } from '../mocks/common'

const waitListEmail: WaitListEmail = {
    email: 'one@mail.com',
    first_name: 'One',
    last_name: 'Two',
    created_at: '2021-02-26',
}

describe('wait list email test', () => {
    const putStub = sinon.stub(mapper.prototype, 'put')
    const batchDeleteStub = sinon.stub(mapper.prototype, 'batchDelete')
    const getStub = sinon.stub(mapper.prototype, 'get')

    afterEach(() => {
        sinon.reset()
    })
    it('should persist wait list email', async () => {
        putStub.resolves(Object.assign(new WaitListEmail(), waitListEmail))
        const saved = await put(waitListEmail)
        expect(saved).toEqual(waitListEmail)
        sinon.assert.calledOnce(putStub)
    })
    it('should throw error if mapper failed to persist data', async () => {
        putStub.rejects(new Error('Unexpected error'))
        await expect(put(waitListEmail)).rejects.toThrow(new Error('Unexpected error'))
        sinon.assert.calledOnce(putStub)
    })
    it('should remove wait list emails', async () => {
        batchDeleteStub.callsFake(() => dataMapperIteratorMock([waitListEmail]))
        await batchRemove([waitListEmail.email])
        sinon.assert.called(batchDeleteStub)
    })
    it('should throw error if mapper failed to remove data', async () => {
        batchDeleteStub.throws(new Error('Unexpected error'))
        await expect(batchRemove([waitListEmail.email])).rejects.toThrow(new Error('Unexpected error'))
    })
    it('should fetch wait list by email', async () => {
        const expected = {
            email: 'one@gmail.com',
            first_name: 'One',
            last_name: 'Two',
        }

        getStub.resolves(expected)
        const actual = await get('one@gmail.com')

        expect(actual).toEqual(expected)
    })
    it('should return undefined if email is not in wait list', async () => {
        getStub.rejects({ name: 'ItemNotFoundException' })
        const actual = await get('one@gmail.com')
        expect(actual).toBeUndefined()
    })
    it('should throw error while getting email from wait list', async () => {
        getStub.rejects(new Error('Internal error'))
        await expect(get('one@gmail.com')).rejects.toThrow('Internal error')
    })
})
