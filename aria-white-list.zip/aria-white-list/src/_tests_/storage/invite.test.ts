import sinon from 'sinon'

import { getInvites, Invite, save, update } from '../../storage/invite'
import { DataMapper as mapper } from '@aws/dynamodb-data-mapper'
import { UpdateExpression } from '@aws/dynamodb-expressions'
import { dataMapperIteratorMock } from '../mocks/common'
import { ConditionExpression, equals } from '@aws/dynamodb-expressions/build/ConditionExpression'

describe('test invite storage', () => {
    afterEach(() => {
        sinon.restore()
    })
    it('should throw error while updating invite', async () => {
        sinon.stub(mapper.prototype, 'executeUpdateExpression').rejects(new Error('Internal error'))

        await expect(update).rejects.toThrow('Internal error')
    })
    it('should not throw error while updating invite if property does not exist', async () => {
        sinon.stub(mapper.prototype, 'executeUpdateExpression').rejects({ name: 'ConditionalCheckFailedException' })

        const result = await update('some@mail.com', new UpdateExpression())
        expect(result).toBeUndefined()
    })
    it('should get invites by condition and filter', async () => {
        const invites = [
            new Invite('one@mail.com', '2021-02-26'),
            new Invite('two@mail.com', '2021-02-27'),
            new Invite('three@mail.com', '2021-02-27'),
        ]
        sinon.stub(mapper.prototype, 'query').callsFake(() => dataMapperIteratorMock(invites))

        const expr: ConditionExpression = {
            type: 'And',
            conditions: [
                {
                    ...equals('false'),
                    subject: 'validated',
                },
                {
                    ...equals(process.env.SEND_EMAILS_MAX_ATTEMPTS),
                    subject: 'sent_at',
                },
            ],
        }

        const filter: ConditionExpression = {
            subject: 'sent_at',
            ...equals('2021-02-27'),
        }

        const result = await getInvites(expr, filter)
        expect(result).toStrictEqual(invites)
    })
    it('should save invite', async () => {
        const invite = new Invite('one@mail.com', '2021-02-26')
        sinon.stub(mapper.prototype, 'put').resolves()

        const result = await save(invite)

        expect(result).toBeUndefined()
    })
    it('should throw error while save invite if mapper throws error', async () => {
        const invite = new Invite('one@mail.com', '2021-02-26')
        sinon.stub(mapper.prototype, 'put').rejects(new Error('Unexpected error'))
        await expect(save(invite)).rejects.toThrow(new Error('Unexpected error'))
    })
})
