import sinon from 'sinon'

import { getByEmail, getByIndex, saveWhitelist, update, WhiteListDetails } from '../../storage/whiteListDetails'
import { DataMapper as mapper } from '@aws/dynamodb-data-mapper'
import { UpdateExpression, FunctionExpression, AttributePath } from '@aws/dynamodb-expressions'
import { dataMapperIteratorMock } from '../mocks/common'
import { equals } from '@aws/dynamodb-expressions/build/ConditionExpression'
import { property } from '@nmg/osp-backend-utils/config'

const input = [
    {
        uca_id: 'werefoxx@gmail.com',
        cmd_id: '12',
        first_name: 'Oleg',
        last_name: 'Bilka',
        email: 'werefoxx@gmail.com',
    },
    {
        uca_id: 'oleg_b@gmail.com',
        cmd_id: '12',
        first_name: 'Alex',
        last_name: 'Banton',
        email: 'test@gmail.com',
    },
]

describe('test whiteListStorage', () => {
    afterEach(() => {
        sinon.restore()
    })
    it('should fetch white list details by email', async () => {
        const expected = {
            email: 'one@gmail.com',
            uca_id: '111',
            cmd_id: '222',
        }

        sinon.stub(mapper.prototype, 'get').resolves(expected)

        const actual = await getByEmail('one@gmail.com')

        expect(actual).toEqual(expected)
    })
    it('should return undefined if email is not in white list', async () => {
        sinon.stub(mapper.prototype, 'get').rejects({ name: 'ItemNotFoundException' })

        const actual = await getByEmail('one@gmail.com')

        expect(actual).toBeUndefined()
    })
    it('should throw error while getting details', async () => {
        sinon.stub(mapper.prototype, 'get').rejects(new Error('Internal error'))
        await expect(getByEmail('one@gmail.com')).rejects.toThrow('Internal error')
    })
    it('should save the whitelist', async () => {
        const update = sinon.stub(mapper.prototype, 'executeUpdateExpression')
        update.resolves()

        await saveWhitelist(input)

        expect(update).toHaveBeenCalled()
    })
/*     it('should throw an error saving the whitelist', async () => {
        sinon.stub(mapper.prototype, 'executeUpdateExpression').rejects(new Error('Internal error'))
        await expect(saveWhitelist()).rejects.toThrow('Internal error')
    }) */
    it('should update white list details', async () => {
        sinon.stub(mapper.prototype, 'executeUpdateExpression').resolves({})
        await update({})
    })
    it('should not update white list details if unexpected error occurred', async () => {
        sinon.stub(mapper.prototype, 'executeUpdateExpression').rejects(new Error('Internal error'))
        await expect(update({})).rejects.toThrow('Internal error')
    })
    it('should white list details with expected expression', async () => {
        const executeUpdate = sinon.stub(mapper.prototype, 'executeUpdateExpression')
        executeUpdate.resolves()
        const joined_at = new Date().toDateString()

        await update({ email: 'one@mail.com', uca_id: '123', joined_at })
        const condition = new FunctionExpression('if_not_exists', new AttributePath('joined_at'), joined_at)

        const expectedExpression = new UpdateExpression()
        expectedExpression.set('uca_id', '123')
        expectedExpression.set('joined_at', condition)
        expect(executeUpdate.getCall(0).args[0]).toEqual(expectedExpression)
        expect(executeUpdate.getCall(0).args[1]).toEqual({ email: 'one@mail.com' })
    })
    it('should get details by index', async () => {
        let expected = [
            {
                uca_id: 'werefoxx@gmail.com',
                cmd_id: '12',
                first_name: 'Oleg',
                last_name: 'Bilka',
                email: 'werefoxx@gmail.com',
            },
        ]

        sinon
            .stub(mapper.prototype, 'query')
            .callsFake(() => dataMapperIteratorMock(expected.map((i) => Object.assign(new WhiteListDetails(), i))))

        const actual = await getByIndex(property('UCA_ID_INDEX'), {
            ...equals('werefoxx@gmail.com'),
            subject: 'uca_id',
        })
        expect(actual).toEqual(expected)
    })
})
