import { WhiteListDetails } from '../storage/whiteListDetails'
import { toWhiteListDetailsDto, toDynamoDBWhitelistDto, toWaitListEmailDto, toWaitListEmail } from '../transformer'
import { ICsvEntry, IWaitListEmail } from '../types'
import { WaitListEmail } from '../storage/waitListEmail'

describe('transformer test', () => {
    it('should convert WhiteListDetails to IWhiteListDetails', () => {
        const whiteListDetails: WhiteListDetails = {
            email: 'One@gmail.com',
            uca_id: '111',
            cmd_id: '222',
            first_name: 'Will',
            last_name: 'Smith',
        }
        const dto = toWhiteListDetailsDto(whiteListDetails)
        expect(dto.email).toEqual(whiteListDetails.email)
        expect(dto.accountId).toEqual(whiteListDetails.uca_id)
        expect(dto.cmdId).toEqual(whiteListDetails.cmd_id)
        expect(dto.firstName).toEqual(whiteListDetails.first_name)
    })
    it('should convert ICsvEntry to WhiteListDetails', () => {
        const csvEntry: ICsvEntry = {
            email: 'One@gmail.com',
            UCA_ID: '111',
            cmd_id: '222',
            first_name: 'Will',
            last_name: 'Smith',
        }
        const dto = toDynamoDBWhitelistDto(csvEntry)
        expect(dto.email).toEqual(csvEntry.email.toLowerCase())
        expect(dto.uca_id).toEqual(csvEntry.UCA_ID)
        expect(dto.cmd_id).toEqual(csvEntry.cmd_id)
        expect(dto.first_name).toEqual(csvEntry.first_name)
        expect(dto.last_name).toEqual(csvEntry.last_name)
    })
    it('should omit missing fields converting ICsvEntry to WhiteListDetails', () => {
        const csvEntry: ICsvEntry = {
            email: 'One@gmail.com',
        }
        const dto = toDynamoDBWhitelistDto(csvEntry)
        expect(dto).toEqual({ email: csvEntry.email.toLowerCase() })
    })
    it('should convert WaitListEmail to IWaitListEmail', () => {
        const waitListEmail: WaitListEmail = {
            email: 'One@gmail.com',
            first_name: 'Will',
            last_name: 'Smith',
            created_at: '2021-02-26',
            phone_number: '+1-123-123',
        }
        const dto = toWaitListEmailDto(waitListEmail)
        expect(dto).toEqual({
            email: waitListEmail.email,
            firstName: waitListEmail.first_name,
            lastName: waitListEmail.last_name,
            createdAt: waitListEmail.created_at,
            phoneNumber: '+1-123-123',
        })
    })
    it('should convert IWaitListEmail to WaitListEmail', () => {
        const dto: IWaitListEmail = {
            email: 'One@gmail.com',
            firstName: 'Will',
            lastName: 'Smith',
            createdAt: '2021-02-26',
            phoneNumber: '+1-123-123',
        }
        const waitListEmail = toWaitListEmail(dto)
        expect(waitListEmail).toEqual({
            email: dto.email.toLowerCase(),
            first_name: dto.firstName,
            last_name: dto.lastName,
            created_at: dto.createdAt,
            phone_number: dto.phoneNumber,
        })
    })
})
