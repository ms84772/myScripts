/* istanbul ignore file */

import { APIGatewayProxyEvent } from 'aws-lambda'
import { QueryIterator, StringToAnyObjectMap } from '@aws/dynamodb-data-mapper'
import { WhiteListDetails } from '../../storage/whiteListDetails'
import { AttributeMap } from 'aws-sdk/clients/dynamodb'

export const getGatewayProxyEventMock = (eventType?: EventParam): APIGatewayProxyEvent => ({
    body: eventType?.body,
    headers: undefined,
    httpMethod: null,
    isBase64Encoded: false,
    multiValueHeaders: undefined,
    multiValueQueryStringParameters: undefined,
    pathParameters: eventType?.pathParameters,
    queryStringParameters: eventType?.queryStringParameters,
    requestContext: {
        authorizer: eventType?.authorizer,
        protocol: undefined,
        accountId: undefined,
        apiId: undefined,
        httpMethod: undefined,
        identity: {
            accessKey: null,
            accountId: null,
            apiKey: null,
            apiKeyId: null,
            caller: null,
            cognitoAuthenticationProvider: null,
            cognitoAuthenticationType: null,
            cognitoIdentityId: null,
            cognitoIdentityPoolId: null,
            sourceIp: undefined,
            user: null,
            userAgent: null,
            userArn: null,
            principalOrgId: null,
        },
        path: undefined,
        stage: undefined,
        requestId: undefined,
        resourceId: undefined,
        resourcePath: undefined,
        requestTimeEpoch: 1,
    },
    resource: '',
    stageVariables: undefined,
    path: '',
})

export class EventParam {
    queryStringParameters?: {}
    authorizer?: {}
    body?: string
    pathParameters?: {}
}

export const dataMapperIteratorMock = (data: any): QueryIterator<StringToAnyObjectMap> => {
    const asyncIteratorMock: any = {}
    asyncIteratorMock[Symbol.asyncIterator] = async function* () {
        let index = 0
        while (index++ < data.length) {
            yield data[index - 1]
        }
    }
    return asyncIteratorMock as QueryIterator<StringToAnyObjectMap>
}

export const dynamoDbWhiteListEvents = (events: any[]) => ({
    Records: events,
})

export const dynamoDbWhiteList = (eventType: string, whiteListDetails: WhiteListDetails) => ({
    eventName: eventType,
    dynamodb: {
        NewImage: {
            email: {
                S: whiteListDetails?.email,
            },
            uca_id: {
                S: whiteListDetails?.uca_id,
            },
        } as AttributeMap,
    },
})
