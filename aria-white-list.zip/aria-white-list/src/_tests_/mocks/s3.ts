/* istanbul ignore file */

import { S3Event } from 'aws-lambda'
import { default as createEvent } from 'aws-event-mocks'

export const getS3EventMock = (): S3Event => {
    return createEvent({
        template: 'aws:s3',
        merge: {
            Records: [
                {
                    eventName: 'ObjectCreated:Put',
                    s3: {
                        bucket: {
                            name: 'my-bucket-name',
                        },
                        object: {
                            key: 'object-key',
                        },
                    },
                },
            ],
        },
    })
}
