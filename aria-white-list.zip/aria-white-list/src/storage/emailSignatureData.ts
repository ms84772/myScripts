import { attribute, hashKey, table } from '@aws/dynamodb-data-mapper-annotations'
import logger from '@nmg/osp-backend-utils/logger'
import { DataMapper } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import { property } from '@nmg/osp-backend-utils/config'

const mapper = new DataMapper({ client: new DynamoDB() })
const tableName = property('EMAIL_SIGNATURE_DATA')

@table(tableName)
export class EmailSignatureData {
    @hashKey()
    associatePin: string
    @attribute()
    office365PhotoHash?: string
    @attribute()
    office365PhotoPublicId?: string
    @attribute()
    office365PhotoUrl?: string
}

export const getByAssociatePin = async (pin: string): Promise<EmailSignatureData> => {
    return mapper.get(Object.assign(new EmailSignatureData(), { associatePin: pin })).catch((err) => {
        if (err.name === 'ItemNotFoundException') {
            return undefined
        }
        logger.error({
            message: `Error getting EmailSignatureData for associatePin: ${pin}, reason: ${err.message}`,
        })
        throw err
    })
}
