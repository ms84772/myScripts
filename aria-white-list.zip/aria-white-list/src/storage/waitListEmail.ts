import { DataMapper } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import { property } from '@nmg/osp-backend-utils/config'
import { attribute, hashKey, table } from '@aws/dynamodb-data-mapper-annotations'
import logger from '@nmg/osp-backend-utils/logger'
import { removeEmptyValues } from '../utils'
import { WhiteListDetails } from './whiteListDetails'

const mapper = new DataMapper({ client: new DynamoDB() })
const tableName = property('WAIT_LIST_EMAILS')

@table(tableName)
export class WaitListEmail {
    @hashKey()
    email?: string
    @attribute()
    created_at?: string
    @attribute()
    first_name?: string
    @attribute()
    last_name?: string
    @attribute()
    phone_number?: string
}

export const put = async (waitListEmail: WaitListEmail): Promise<WaitListEmail> => {
    try {
        return await mapper.put(Object.assign(new WaitListEmail(), removeEmptyValues(waitListEmail)))
    } catch (error) {
        logger.error({ message: 'Error persisting wait list email.', item: waitListEmail })
        throw error
    }
}

export const batchRemove = async (emails: string[]): Promise<void> => {
    const emailsToRemove: WaitListEmail[] = emails.map((email) => {
        return Object.assign(new WaitListEmail(), { email: email })
    })
    try {
        for await (const found of mapper.batchDelete(emailsToRemove)) {
            logger.debug(`Email ${found?.email} was processed`)
        }
    } catch (error) {
        logger.error({ message: 'Error removing wait list emails.', items: emails })
        throw error
    }
}

export const get = async (email: string): Promise<WhiteListDetails> => {
    return mapper.get(Object.assign(new WaitListEmail(), { email: email })).catch((err) => {
        if (err.name === 'ItemNotFoundException') {
            return undefined
        }
        logger.error({
            message: `Error getting wait list for email: ${email}, reason: ${err.message}`,
        })
        throw err
    })
}
