import { attribute, hashKey, table } from '@aws/dynamodb-data-mapper-annotations'
import logger from '@nmg/osp-backend-utils/logger'
import { DataMapper } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import { property } from '@nmg/osp-backend-utils/config'

const mapper = new DataMapper({ client: new DynamoDB() })
const tableName = property('OSP_ORG_HIERARCHY')

@table(tableName)
export class OspOrgHierarchy {
    @hashKey()
    associatePin: string
    @attribute()
    email?: string
    @attribute()
    firstName?: string
    @attribute()
    isActive?: boolean
    @attribute()
    lastName?: string
    @attribute()
    path?: string
    @attribute()
    sequenceNumber?: number
    @attribute()
    storeId?: string
    @attribute()
    updateDateTime?: string
    @attribute()
    workPhone?: string[]
    @attribute()
    mobilePhone?: string
}

export const getByAssociatePin = async (pin: string): Promise<OspOrgHierarchy> => {
    return mapper.get(Object.assign(new OspOrgHierarchy(), { associatePin: pin })).catch((err) => {
        if (err.name === 'ItemNotFoundException') {
            return undefined
        }
        logger.error({
            message: `Error getting OspOrgHierarchy for associatePin: ${pin}, reason: ${err.message}`,
        })
        throw err
    })
}
