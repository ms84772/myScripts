import { attribute, hashKey, table } from '@aws/dynamodb-data-mapper-annotations'
import { DataMapper, ExecuteUpdateExpressionOptions } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import { property } from '@nmg/osp-backend-utils/config'
import { UpdateExpression } from '@aws/dynamodb-expressions'
import { ConditionExpression } from '@aws/dynamodb-expressions/build/ConditionExpression'
import logger from '@nmg/osp-backend-utils/logger'
import { toDateTime } from '../utils'

const mapper = new DataMapper({ client: new DynamoDB() })
const validatedSentTimesIndex = property('VALIDATED_SENT_TIMES_INDEX')
const tableName = property('INVITES')

@table(tableName)
export class Invite {
    @hashKey()
    email?: string
    @attribute({ defaultProvider: () => false })
    validated?: string
    @attribute()
    sent_at?: string
    @attribute({ defaultProvider: () => toDateTime(new Date()) })
    created_at?: string
    @attribute({ defaultProvider: () => 0 })
    sent_times?: number

    constructor(email?, sent_at?) {
        this.email = email
        this.sent_at = sent_at
    }
}

export const update = async (
    email: string,
    expr: UpdateExpression,
    options?: ExecuteUpdateExpressionOptions,
): Promise<void> => {
    try {
        await mapper.executeUpdateExpression(expr, { email: email }, Invite, options)
    } catch (error) {
        if (error.name === 'ConditionalCheckFailedException') {
            return
        }
        throw error
    }
}

export const save = async (invite: Invite): Promise<void> => {
    logger.info(`Save invite: ${JSON.stringify(invite)}`)
    try {
        await mapper.put(Object.assign(new Invite(), invite))
        logger.info('Invite was saved')
    } catch (error) {
        logger.error({ message: `Error persisting invite ${invite}, errorMessage: ${error}` })
        throw error
    }
}

export const saveAll = async (invites: Array<Invite>): Promise<void> => {
    logger.info(`Save invites: ${JSON.stringify(invites)}`)
    try {
        const toSave = invites.map((invite) => Object.assign(new Invite(), invite))
        logger.debug({ message: `saving invites to table ${tableName}`, data: toSave })
        for await (const _item of mapper.batchPut(toSave)) {
        }
    } catch (error) {
        logger.error({ message: `Error persisting invites ${invites}, errorMessage: ${error}` })
        throw error
    }
}

export const getInvites = async (expr: ConditionExpression, filter: ConditionExpression): Promise<Invite[]> => {
    const iterator = mapper.query(Invite, expr, { indexName: validatedSentTimesIndex, filter: filter })
    const invites: Invite[] = []
    for await (const invite of iterator) {
        invites.push(invite)
    }
    return invites
}
