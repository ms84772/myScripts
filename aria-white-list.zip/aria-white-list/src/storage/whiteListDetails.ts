import { attribute, hashKey, table } from '@aws/dynamodb-data-mapper-annotations'
import { property } from '@nmg/osp-backend-utils/config'
import { DataMapper } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import logger from '@nmg/osp-backend-utils/logger'
import { Schema } from '@aws/dynamodb-data-marshaller'
import { AttributePath, FunctionExpression, UpdateExpression, ConditionExpression } from '@aws/dynamodb-expressions'

const mapper = new DataMapper({ client: new DynamoDB() })
const tableName = property('WHITE_LIST_EMAILS')

@table(tableName)
export class WhiteListDetails {
    @hashKey()
    email?: string
    @attribute()
    uca_id?: string
    @attribute()
    cmd_id?: string
    @attribute()
    first_name?: string
    @attribute()
    last_name?: string
    @attribute()
    associatePin?: string
    @attribute()
    joined_at?: string
    @attribute()
    onboarded_at?: string
}

export const whiteListDetailsSchema: Schema = {
    email: { type: 'String', keyType: 'HASH' },
    uca_id: { type: 'String' },
    cmd_id: { type: 'String' },
    first_name: { type: 'String' },
    last_name: { type: 'String' },
    associatePin: { type: 'String' },
    joined_at: { type: 'String' },
    onboarded_at: { type: 'String' },
}

export const getByEmail = async (email: string): Promise<WhiteListDetails> => {
    return mapper.get(Object.assign(new WhiteListDetails(), { email: email })).catch((err) => {
        if (err.name === 'ItemNotFoundException') {
            return undefined
        }
        logger.error({
            message: `Error getting white list details for email: ${email}, reason: ${err.message}`,
        })
        throw err
    })
}

export const getByIndex = async (
    index: string,
    expr: ConditionExpression,
    filter?: ConditionExpression,
): Promise<WhiteListDetails[]> => {
    const iterator = mapper.query(WhiteListDetails, expr, { indexName: index, filter: filter })
    const items: WhiteListDetails[] = []
    for await (const item of iterator) {
        items.push(item)
    }
    return items
}

export const saveWhitelist = async (items: Array<any>): Promise<any> => {
    try {
        for (let item of items) {
            const expression = new UpdateExpression()
            const condition = new FunctionExpression('if_not_exists', new AttributePath('uca_id'), item.uca_id)
            Object.keys(item)
                .filter((key) => key !== 'email' && key !== 'uca_id')
                .forEach((key) => {
                    expression.set(key, item[key])
                })
            if (item.uca_id) {
                expression.set('uca_id', condition)
            }
            await mapper.executeUpdateExpression(expression, { email: item.email }, WhiteListDetails)
        }
        logger.debug({ message: `saving data to table ${tableName}`, data: items })
        logger.debug('items saved successfully')
    } catch (error) {
        logger.error(`Error while saving whitelist to DynamoDB, reason: ${error.toString()}`)
        throw error
    }
}
export const update = async (details: WhiteListDetails): Promise<void> => {
    const expression = new UpdateExpression()
    Object.keys(details)
        .filter((key) => key !== 'email' && key !== 'joined_at')
        .forEach((key) => {
            expression.set(key, details[key])
        })
    if (details.joined_at) {
        const condition = new FunctionExpression('if_not_exists', new AttributePath('joined_at'), details.joined_at)
        expression.set('joined_at', condition)
    }
    await mapper.executeUpdateExpression(expression, { email: details.email }, WhiteListDetails).catch((error) => {
        logger.error(`error persisting the whiteListDetails for email ${details.email}: ${error.toString()}`)
        throw new Error(error)
    })
}
