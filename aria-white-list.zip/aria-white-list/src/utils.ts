import AWS from 'aws-sdk'
import logger from '@nmg/osp-backend-utils/logger'
import response from '@nmg/osp-backend-utils/http/response'
import { APIGatewayProxyResult } from 'aws-lambda'
import { LogData } from '@nmg/osp-backend-utils/types'

export const logAndReturnErr = (statusCode: number, msg: string | LogData): APIGatewayProxyResult => {
    logger.error(msg)
    return response.error(statusCode, msg)
}

export const toShortDate = (date: Date) => date.toISOString().substring(0, 10)
export const toDateTime = (date: Date) => date.toISOString().substring(0, 16)

export const removeEmptyValues = (obj: Record<string, any>): Record<string, any> => {
    Object.keys(obj).forEach((key) => {
        if (obj[key] === null || obj[key] === undefined || obj[key] === '') {
            delete obj[key]
        }
    })
    return obj
}

export const validateEmail = (email: string) => {
    // eslint-disable-next-line
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
}

export const uploadFile = async (bucket, key, fileContent) => {
    const s3 = new AWS.S3()
    const params = {
        Bucket: bucket,
        Key: key,
        Body: fileContent,
    }

    // Uploading files to the bucket
    await s3.upload(params).promise()
    logger.debug(`File ${key} uploaded successfully.`)
}

export const decodeS3Key = (key: string): string => decodeURIComponent(key?.replace(/\+/g, ' '))
