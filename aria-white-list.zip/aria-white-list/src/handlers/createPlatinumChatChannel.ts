import logger from '@nmg/osp-backend-utils/logger'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import { logAndReturnErr } from '../utils'
import { createTwilioPlatinumChatChannel } from '../service/chatService'
import { PlatinumChatInfo } from '../types'
import response from '@nmg/osp-backend-utils/http/response'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const payload: PlatinumChatInfo = JSON.parse(event?.body || '{}')
    logger.debug({
        message: 'create platinum chat channel',
        ucaId: event.pathParameters?.ucaId,
    })
    try {
        const result = await createTwilioPlatinumChatChannel(payload)
        return response.ok(result)
    } catch (error) {
        return logAndReturnErr(500, {
            message: `Error occurred during creating platinum chat channel`,
            errorMessage: `${error}`,
            ucaId: event.pathParameters?.ucaId,
        })
    }
}
