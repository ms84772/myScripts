import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import response from '@nmg/osp-backend-utils/http/response'
import logger from '@nmg/osp-backend-utils/logger'
import { getByAssociatePin as getOspHierarchyByPin, OspOrgHierarchy } from '../storage/ospOrgHierarchy'
import { EmailSignatureData, getByAssociatePin as getEmailSignatureByPin } from '../storage/emailSignatureData'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const pin = event.pathParameters.pin
    try {
        logger.debug(`Get associate info by pin: ${pin}`)
        const ospOrgHierarchy: OspOrgHierarchy = await getOspHierarchyByPin(pin)
        const emailSignatureData: EmailSignatureData = await getEmailSignatureByPin(pin)
        return response.ok({
            ...ospOrgHierarchy,
            office365PhotoUrl: emailSignatureData?.office365PhotoUrl,
        })
    } catch (error) {
        return logAndReturnErr(500, {
            message: `Error occurred during getAssociateInfo by pin ${pin}`,
            errorMessage: `${error}`,
        })
    }
}
