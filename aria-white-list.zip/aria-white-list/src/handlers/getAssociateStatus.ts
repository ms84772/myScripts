import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import response from '@nmg/osp-backend-utils/http/response'
import logger from '@nmg/osp-backend-utils/logger'
import { getAssociateStatusByPin } from '../service/chatService'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const pin = event.pathParameters.pin
    logger.debug(`Get associate status by pin: ${pin}`)
    try {
        const associateStatus = await getAssociateStatusByPin(pin)
        return response.ok(associateStatus)
    } catch (error) {
        return logAndReturnErr(500, {
            message: `Error occurred during getAssociateInfo by pin ${pin}`,
            errorMessage: `${error}`,
        })
    }
}
