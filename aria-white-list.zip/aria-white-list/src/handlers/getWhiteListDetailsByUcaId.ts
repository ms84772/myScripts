import logger from '@nmg/osp-backend-utils/logger'
import response from '@nmg/osp-backend-utils/http/response'
import { getDetailsByUcaId } from '../service/whiteListService'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: any): Promise<any> => {
    let ucaId = event?.requestContext?.authorizer?.sub || event.ucaId
    try {
        logger.debug(`Get getWhiteListDetailsByUcaId: ${ucaId}`)
        const details = await getDetailsByUcaId(ucaId)
        if (event.ucaId) {
            return details
        }
        return response.ok(details)
    } catch (error) {
        logger.error(`Error occurred during getWhiteListDetailsByUcaId ${ucaId}, errorMessage: ${error}`)
        throw error
    }
}
