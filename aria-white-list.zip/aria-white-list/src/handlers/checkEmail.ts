import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import response from '@nmg/osp-backend-utils/http/response'
import logger from '@nmg/osp-backend-utils/logger'
import { getWhiteListDetails } from '../service/whiteListService'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    let email: string = event.queryStringParameters?.email
    if (!email || !email.trim()) {
        return logAndReturnErr(400, 'Email parameter can not be empty')
    }
    let details
    email = email.toLowerCase()
    try {
        logger.info(`Get white list details for email: ${email}`)
        details = await getWhiteListDetails(email)
        if (!details) {
            return logAndReturnErr(404, `User not found for email: ${email}`)
        }
    } catch (error) {
        return logAndReturnErr(500, { message: `Error occurred during check email: ${email}, errorMessage: ${error}` })
    }
    return response.ok(details)
}
