import { resendUnacceptedInvites, sendFirstInvites } from '../service/inviteService'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (): Promise<void> => {
    await sendFirstInvites()
    await resendUnacceptedInvites()
}
