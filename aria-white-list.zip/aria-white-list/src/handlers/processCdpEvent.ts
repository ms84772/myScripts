import { S3Event } from 'aws-lambda'
import logger from '@nmg/osp-backend-utils/logger'
import { handle as loadS3WhiteList } from '../handlers/loadS3WhiteList'
import { SNSMessage, SQSEvent } from 'aws-lambda'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: SQSEvent): Promise<void> => {
    logger.info(`Received event: ${JSON.stringify(event)}`)
    await Promise.all(
        event.Records.map(async (record) => {
            const snsMessage: SNSMessage = JSON.parse(record.body)
            logger.info(`Received body: ${JSON.stringify(snsMessage)}`)
            const s3Event: S3Event = JSON.parse(snsMessage.Message)
            logger.info(`Received CDP event: ${JSON.stringify(s3Event)}`)
            await loadS3WhiteList(s3Event, false)
        }),
    )
}
