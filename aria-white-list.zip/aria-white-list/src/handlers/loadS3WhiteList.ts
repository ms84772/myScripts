import { S3Event } from 'aws-lambda'
import logger from '@nmg/osp-backend-utils/logger'
import { fetchS3Whitelist } from '../service/S3whitelistService'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: S3Event, deleteSource: boolean = true): Promise<any> => {
    const srcBucket = event.Records[0].s3.bucket.name
    logger.debug(`Loading data from bucket: ${srcBucket}`)
    // File name may have spaces or unicode non-ASCII characters.
    const srcFileName = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '))
    return await fetchS3Whitelist(srcBucket, srcFileName, deleteSource)
}
