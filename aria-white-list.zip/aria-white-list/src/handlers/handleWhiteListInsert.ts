import { convertToWhiteListDetails, saveInvites, sendToHistoryTopic } from '../service/whiteListService'
import { removeFromWaitList } from '../service/waitListService'
import logger from '@nmg/osp-backend-utils/logger'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: any) => {
    const nonListenedActions: string[] = ['MODIFY', 'REMOVE']
    try {
        const insertRecords = event.Records.filter((record) => !nonListenedActions.includes(record.eventName))
        const details = convertToWhiteListDetails(insertRecords)
        if (details && details.length != 0) {
            await saveInvites(details)
            await removeFromWaitList(details)
            await sendToHistoryTopic(details)
        }
    } catch (error) {
        logger.error(`Error occurred during handleWhiteListInsert, errorMessage: ${error}`)
    }
}
