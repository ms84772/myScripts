import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import response from '@nmg/osp-backend-utils/http/response'
import { getTwilioToken } from '../service/chatService'
import { Authentication } from '../types'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const { sub: ucaId } = event.requestContext.authorizer as Authentication
    if (!ucaId) {
        return logAndReturnErr(400, 'Invalid authorization parameter')
    }
    let token
    try {
        token = await getTwilioToken(ucaId)
    } catch (error) {
        return logAndReturnErr(500, { message: 'Error occurred during creating chat token', errorMessage: `${error}` })
    }
    return response.ok({ token })
}
