import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import { emailExists, saveToWaitList } from '../service/waitListService'
import { sendWaitListConfirmation } from '../service/emailService'
import response from '@nmg/osp-backend-utils/http/response'
import logger from '@nmg/osp-backend-utils/logger'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const payload = JSON.parse(event?.body || '{}')
    const email = payload?.email?.trim()
    if (!email) {
        return logAndReturnErr(400, 'Email can not be empty')
    }
    try {
        if (await emailExists(email)) {
            return logAndReturnErr(409, `Email ${email} already in wait list`)
        }
        const savedEmail = await saveToWaitList({
            email: email,
            firstName: payload?.firstName,
            lastName: payload?.lastName,
            phoneNumber: payload?.phoneNumber,
        })
        await sendWaitListConfirmation(email)
        logger.info(`email: ${email} was saved to wait list`)
        return response.ok(savedEmail)
    } catch (error) {
        return logAndReturnErr(500, {
            message: `Error occurred during processing wait list email ${email}`,
            errorMessage: `${error}`,
        })
    }
}
