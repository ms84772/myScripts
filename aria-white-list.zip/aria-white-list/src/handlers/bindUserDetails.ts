import { logAndReturnErr } from '../utils'
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda'
import response from '@nmg/osp-backend-utils/http/response'
import logger from '@nmg/osp-backend-utils/logger'
import { bindEmailAndAccountId } from '../service/whiteListService'
import { Authentication } from '../types'
import http from 'http'
import https from 'https'
import AWSXRay from 'aws-xray-sdk'

AWSXRay.captureHTTPsGlobal(http, true)
AWSXRay.captureHTTPsGlobal(https, true)

export const handle = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    const { sub: ucaId, email } = event.requestContext.authorizer as Authentication
    if (!ucaId || !email) {
        return logAndReturnErr(400, 'Invalid authorization parameter')
    }
    try {
        await bindEmailAndAccountId(email, ucaId)
        logger.info(`email: ${email} and accountId: ${ucaId} were successfully binded`)
    } catch (error) {
        return logAndReturnErr(500, { message: 'Error occurred during binding user details', errorMessage: `${error}` })
    }
    return response.ok()
}
