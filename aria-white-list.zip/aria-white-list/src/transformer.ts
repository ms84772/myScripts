import { ICsvEntry, IWaitListEmail, IWhiteListDetails } from './types'
import { WhiteListDetails } from './storage/whiteListDetails'
import { WaitListEmail } from './storage/waitListEmail'

export const toWhiteListDetailsDto = (whiteListDetails: WhiteListDetails): IWhiteListDetails => ({
    email: whiteListDetails?.email,
    accountId: whiteListDetails?.uca_id,
    cmdId: whiteListDetails?.cmd_id,
    firstName: whiteListDetails?.first_name,
    lastName: whiteListDetails?.last_name,
    associatePin: whiteListDetails?.associatePin,
    onboarded_at: whiteListDetails?.onboarded_at,
    onboarded: !!whiteListDetails?.onboarded_at,
})

export const toDynamoDBWhitelistDto = (csvEntry: ICsvEntry): WhiteListDetails => ({
    email: String(csvEntry.email).toLowerCase(),
    ...(csvEntry?.UCA_ID && { uca_id: String(csvEntry.UCA_ID).toLowerCase() }),
    ...(csvEntry?.cmd_id && { cmd_id: csvEntry.cmd_id }),
    ...(csvEntry?.first_name && { first_name: csvEntry.first_name }),
    ...(csvEntry?.last_name && { last_name: csvEntry.last_name }),
    ...(csvEntry?.associatePin && { associatePin: csvEntry.associatePin }),
})

export const toWaitListEmailDto = (waitListEmail: WaitListEmail): IWaitListEmail => ({
    email: waitListEmail?.email,
    createdAt: waitListEmail?.created_at,
    firstName: waitListEmail?.first_name,
    lastName: waitListEmail?.last_name,
    phoneNumber: waitListEmail?.phone_number,
})

export const toWaitListEmail = (waitListEmail: IWaitListEmail): WaitListEmail => ({
    email: String(waitListEmail.email).toLowerCase(),
    created_at: waitListEmail?.createdAt,
    first_name: waitListEmail?.firstName,
    last_name: waitListEmail?.lastName,
    phone_number: waitListEmail?.phoneNumber,
})
