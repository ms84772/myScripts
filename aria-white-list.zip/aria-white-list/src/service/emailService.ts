import { Lambda } from 'aws-sdk'
import logger from '@nmg/osp-backend-utils/logger'
import { property } from '@nmg/osp-backend-utils/config'
import { Feature } from '@nmg/aria-backend-utils/optimizely/Feature'

const sendEmailArn = property('SEND_EMAIL_ARN')
const waitListTemplate = property('SEND_EMAIL_WAIT_LIST_TEMPLATE')
const invitationTemplate = property('SEND_EMAIL_INVITATION_TEMPLATE')
const defaultBrand = property('SEND_EMAIL_DEFAULT_BRAND')
const invitationSubject = property('SEND_EMAIL_INVITATION_SUBJECT')
const waitListSubject = property('SEND_EMAIL_WAIT_LIST_SUBJECT')

export const sendInvitationEmail = async (email: string, payload?: any): Promise<void> => {
    if (await Feature.isEnabled(property('SEND_EMAIL_INVITATION_ENABLED'), email)) {
        logger.debug(`Send white list invitation for email: ${email}`)
        await sendEmail({
            queryStringParameters: {
                brand: defaultBrand,
                templateId: invitationTemplate,
            },
            body: JSON.stringify({
                subject: invitationSubject,
                emailsTo: [email],
                payload: payload,
            }),
        })
    }
}

export const sendWaitListConfirmation = async (email: string): Promise<void> => {
    if (await Feature.isEnabled(property('SEND_EMAIL_WAIT_LIST_ENABLED'), email)) {
        logger.debug(`Send wait list confirmation for email: ${email}`)
        await sendEmail({
            queryStringParameters: {
                brand: defaultBrand,
                templateId: waitListTemplate,
            },
            body: JSON.stringify({
                subject: waitListSubject,
                emailsTo: [email],
            }),
        })
    }
}

const sendEmail = async (payload: any): Promise<any> => {
    try {
        const lambda = new Lambda()
        await lambda
            .invoke({
                FunctionName: sendEmailArn,
                InvocationType: 'RequestResponse',
                Payload: JSON.stringify(payload),
            })
            .promise()
    } catch (error) {
        logger.error({
            message: 'Error invoking function.',
            FunctionName: sendEmailArn,
            errorCode: error.code,
            errorMessage: error.message,
        })
    }
}
