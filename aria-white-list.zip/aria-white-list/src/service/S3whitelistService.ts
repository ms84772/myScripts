import AWS from 'aws-sdk'
import csv from 'csvtojson'
import logger from '@nmg/osp-backend-utils/logger'
import { saveWhitelist } from '../storage/whiteListDetails'
import { validateEmail } from '../utils'
import { toDynamoDBWhitelistDto } from '../transformer'
import { Parser } from 'json2csv'
import { uploadFile } from '../utils'
import { csvEntryKeys } from '../types'
export const fetchS3Whitelist = async (bucket: string, key: string, deleteSource: boolean = true): Promise<any> => {
    logger.debug(`Getting whitelist ${key} from bucket ${bucket}`)
    const s3 = new AWS.S3()
    const copyObject = async (bucket, from, to, targetBucket, params = {}) => {
        logger.info(`Copying file from ${from}, to ${to}, target bucket: ${targetBucket}`)
        await s3
            .copyObject({
                Bucket: targetBucket,
                CopySource: `/${bucket}/${from}`,
                Key: to,
                ...params,
            })
            .promise()
    }
    try {
        await processS3File(bucket, key)
        await copyObject(bucket, key, getTargetFileName(key, `processed/${Date.now()}-`), process.env.WHITE_LIST_BUCKET)
        await copyObject(
            bucket,
            key,
            getTargetFileName(key, `stanleyApp/${Date.now()}-`),
            process.env.WHITE_LIST_BUCKET,
        )
        await copyObject(
            bucket,
            key,
            getTargetFileName(key, `stanleyApp/${Date.now()}-`),
            process.env.EDA_LIST_BUCKET,
            {
                ACL: 'bucket-owner-full-control',
            },
        )
        await deleteFile(s3, bucket, key, deleteSource)
    } catch (error) {
        logger.error(`Error processing S3 whitelist ${error.name}: ${error.message}`)
        // TODO: find a way to catch CSV Parse Error 'CSV Parse Error'
        if (error.name === 'ValidationError' || error.name === 'TypeError') {
            await copyObject(
                bucket,
                key,
                key.replace(process.env.WHITE_LIST_PREFIX, `failed/${Date.now()}-`),
                process.env.WHITE_LIST_BUCKET,
            )
            await deleteFile(s3, bucket, key, deleteSource)
        }
        throw error
    }
}

/**
 * If file belongs to different account, we shouldn`t delete it
 * @param s3
 * @param bucket
 * @param key
 * @param deleteSource
 */
const deleteFile = async (s3, bucket, key, deleteSource) => {
    if (deleteSource) {
        await s3
            .deleteObject({
                Bucket: bucket,
                Key: key,
            })
            .promise()
    }
}

const processS3File = async (bucket: string, key: string): Promise<any> => {
    logger.debug(`Getting file ${key} from bucket ${bucket}`)
    const s3 = new AWS.S3()
    const response = await s3
        .getObject({
            Bucket: bucket,
            Key: key,
        })
        .promise()
    logger.debug(`Fetched file successfully, parsing ${key}`)
    const csvString = response.Body.toString()
    const fields = csvEntryKeys
    const opts = { fields, quote: '' }
    const parser = new Parser(opts)
    let items = []
    let errors = []
    await csv({
        delimiter: ',',
    })
        .fromString(csvString)
        .subscribe((json, index) => {
            const email = json?.email
            if (!email || !validateEmail(email)) {
                logger.debug(`E-mail validation error in file: ${key}, line: ${index}`)
                errors.push(json)
                return
            }
            items.push(toDynamoDBWhitelistDto(json))
        })
    if (items.length) await saveWhitelist(items)
    if (errors.length) {
        const errorsCSV = parser.parse(errors)
        await uploadFile(bucket, key.replace(process.env.WHITE_LIST_PREFIX, `failed/${Date.now()}-`), errorsCSV)
    }
}
/**
 * Files might come from different accounts. By default, it is located under 'uploads' folder, that is not required for
 * files located in other accounts. Once file is processed, it is moved  to 'processed' folder and get
 * timestamp prefix appended in the beginning of it
 *
 * @param fileName full S3 file name
 * @param newPrefix new file prefix
 */
const getTargetFileName = (fileName: string, newPrefix: string): string => {
    const pathParts = fileName.split('/')
    const originFileName = pathParts?.[pathParts.length - 1]
    return originFileName.startsWith(process.env.WHITE_LIST_PREFIX)
        ? originFileName.replace(process.env.WHITE_LIST_PREFIX, newPrefix)
        : newPrefix + originFileName
}
