import { getByEmail, getByIndex, update, WhiteListDetails, whiteListDetailsSchema } from '../storage/whiteListDetails'
import { toWhiteListDetailsDto } from '../transformer'
import { IWhiteListDetails } from '../types'
import logger from '@nmg/osp-backend-utils/logger'
import { markValidated } from './inviteService'
import { Invite, save, saveAll } from '../storage/invite'
import { sendInvitationEmail } from './emailService'
import { property } from '@nmg/osp-backend-utils/config'
import { equals } from '@aws/dynamodb-expressions/build/ConditionExpression'
import AWS from 'aws-sdk'
import { unmarshallItem } from '@aws/dynamodb-data-marshaller'

export const getWhiteListDetails = async (email: string): Promise<IWhiteListDetails> => {
    logger.info(`Get white list details for email: ${email}`)
    const details = await getByEmail(email)
    logger.info(`Get white list details result: ${JSON.stringify(details)}`)
    if (details) {
        await markValidated(email)
        return toWhiteListDetailsDto(details)
    }
    return undefined
}

export const saveInvites = async (details: WhiteListDetails[]): Promise<void> => {
    await saveAll(details.map((detail) => new Invite(detail.email)))
}

export const sendEmail = async (details: WhiteListDetails): Promise<void> => {
    try {
        await sendInvitationEmail(details.email, { email: details.email })
        const invite: Invite = { email: details.email }
        await save(invite)
    } catch (e) {
        logger.error(`Unable to process white list details: ${details}, reason: ${e}`)
    }
}

export const bindEmailAndAccountId = async (email: string, accountId: string) => {
    await update({ email: email, uca_id: accountId, joined_at: new Date().toISOString() })
}

export const setOnBoarded = async (email: string) => {
    await update({ email: email, onboarded_at: new Date().toISOString() })
}

export const getDetailsByUcaId = async (ucaId: string): Promise<IWhiteListDetails> => {
    const details = await getByIndex(property('UCA_ID_INDEX'), {
        ...equals(ucaId),
        subject: 'uca_id',
    })
    if (details) {
        return toWhiteListDetailsDto(details[0])
    }
    return undefined
}

export const sendToHistoryTopic = async (details: WhiteListDetails[]): Promise<void> => {
    logger.debug(`Sending details to history SNS: ${JSON.stringify(details)}`)
    let sns = new AWS.SNS()
    await sns
        .publish({
            TopicArn: process.env.WAIT_LIST_HISTORY_SNS_ARN,
            Subject: 'Stanley whitelist emails',
            Message: JSON.stringify(details),
        })
        .promise()
        .then((result) => logger.debug(`Details successfully sent, result: ${JSON.stringify(result)}`))
        .catch((error) => logger.error(`Error occurred during sending details to history topic, error: ${error}`))
}

export const convertToWhiteListDetails = (records: any[]): WhiteListDetails[] => {
    return records.map((record) => unmarshallItem(whiteListDetailsSchema, record.dynamodb.NewImage))
}
