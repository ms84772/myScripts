import { Lambda } from 'aws-sdk'
import { jwt } from 'twilio'
import logger from '@nmg/osp-backend-utils/logger'
import { property } from '@nmg/osp-backend-utils/config'
import { InvocationResponse } from 'aws-sdk/clients/lambda'
import { BusinessError } from '@nmg/osp-backend-utils/types'
import request from '@nmg/osp-backend-utils/http/request'
import { PlatinumChatInfo } from '../types'

const AccessToken = jwt.AccessToken
const ChatGrant = AccessToken.ChatGrant

const twilioAccountSid: string = property('TWILIO_ACCOUNT_SID')
const twilioApiKey: string = property('TWILIO_API_KEY')
const twilioApiSecret: string = property('TWILIO_API_SECRET')
const chatServiceSid = property('TWILIO_CHAT_SRV_SID')
const twilioTokenTtl = +property('TWILIO_TOKEN_TTL')

const platinumChatAccountSid = property('PLATINUM_CHAT_ACCOUNT_SID')
const platinumChatServiceSid = property('PLATINUM_CHAT_SERVICE_SID')
const platinumChatApiKey = property('PLATINUM_CHAT_API_KEY')
const platinumChatSecretKey = property('PLATINUM_CHAT_SECRET_KEY')
const getAssociateStatusArn = property('GET_ASSOCIATE_STATUS_ARN')
const flexFlowSid = property('PLATINUM_CHAT_FLEX_FLOW_SID')
const platinumChatFlexFlowUrl = property('PLATINUM_CHAT_FLEX_FLOW_URL')

export const getTwilioToken = async (ucaId: string): Promise<String> => {
    logger.debug(`Creating token for ${ucaId}`)
    const twilioAccessTokenTtlInSec = twilioTokenTtl || 60 * 60
    const token = new AccessToken(twilioAccountSid, twilioApiKey, twilioApiSecret, {
        identity: ucaId,
        ttl: twilioAccessTokenTtlInSec,
    })
    const chatGrant = new ChatGrant({
        serviceSid: chatServiceSid,
    })
    token.addGrant(chatGrant)
    logger.debug(`Token granted for ${ucaId}`)
    return token.toJwt()
}

export const getTwilioPlatinumChatToken = async (ucaId: string): Promise<String> => {
    logger.debug(`Creating platinum chat token for ${ucaId}`)
    const twilioAccessTokenTtlInSec = twilioTokenTtl || 60 * 60
    const token = new AccessToken(platinumChatAccountSid, platinumChatApiKey, platinumChatSecretKey, {
        identity: ucaId,
        ttl: twilioAccessTokenTtlInSec,
    })
    const chatGrant = new ChatGrant({
        serviceSid: platinumChatServiceSid,
    })
    token.addGrant(chatGrant)
    logger.debug(`Platinum chat token granted for ${ucaId}`)
    return token.toJwt()
}

export const getAssociateStatusByPin = async (associatePin: string): Promise<any> => {
    logger.debug(`associatePin parameter ${associatePin}`)
    const lambda = new Lambda()
    const payload = {
        arguments: { associatePin },
    }
    const response: InvocationResponse = await lambda
        .invoke({
            FunctionName: getAssociateStatusArn,
            InvocationType: 'RequestResponse',
            Payload: JSON.stringify(payload),
        })
        .promise()
    const responsePayload = JSON.parse(response.Payload as string)
    const body = JSON.parse(responsePayload?.body)
    if (response.StatusCode != 200 || (responsePayload?.statusCode && responsePayload.statusCode != 200)) {
        logger.error(`Error from lambda: ${JSON.stringify(response)}`)
        throw new BusinessError(response.StatusCode, body)
    }
    return body
}

export const createTwilioPlatinumChatChannel = async (platinumChatInfo: PlatinumChatInfo): Promise<any> => {
    logger.debug({
        message: 'create platinum chat channel',
        ucaId: platinumChatInfo?.userInfo?.ucaId,
    })
    const preEngagementData = {
        location: platinumChatInfo?.location,
        isPlatinum: true,
        firstName: platinumChatInfo?.userInfo?.given_name,
        lastName: platinumChatInfo?.userInfo?.family_name,
        emailAddr: platinumChatInfo?.userInfo?.email,
        platinumData: { chatOption: platinumChatInfo.chatOption },
        brand: 'Neiman Marcus',
    }
    const token = Buffer.from(`${platinumChatApiKey}:${platinumChatSecretKey}`).toString('base64')
    const urlencoded = new URLSearchParams()
    urlencoded.append('FlexFlowSid', flexFlowSid)
    urlencoded.append('Identity', platinumChatInfo?.userInfo?.ucaId)
    urlencoded.append('ChatFriendlyName', 'Stanley App')
    urlencoded.append(
        'ChatUserFriendlyName',
        platinumChatInfo?.userInfo?.given_name + ' ' + platinumChatInfo?.userInfo?.family_name,
    )
    urlencoded.append('PreEngagementData', JSON.stringify(preEngagementData))
    return await request
        .post(platinumChatFlexFlowUrl, urlencoded, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Basic ${token}`,
            },
        })
        .then(({ data }) => data)
        .catch((error) => {
            const message = 'Unable to create platinum chat channel'
            logger.error({
                message,
                errorMessage: error?.response?.data || error.message,
            })
            throw new BusinessError(error?.response?.status, message)
        })
}
