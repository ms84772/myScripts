import { AttributePath, FunctionExpression, UpdateExpression } from '@aws/dynamodb-expressions'
import { getInvites, Invite, update } from '../storage/invite'
import {
    AndExpression,
    ConditionExpression,
    equals,
    between,
    lessThanOrEqualTo,
} from '@aws/dynamodb-expressions/build/ConditionExpression'
import logger from '@nmg/osp-backend-utils/logger'
import { toDateTime, toShortDate } from '../utils'
import { sendInvitationEmail } from './emailService'
import { property } from '@nmg/osp-backend-utils/config'

const sendEmailsMaxAttempts: number = +property('SEND_EMAILS_MAX_ATTEMPTS')

export const markValidated = async (email: string) => {
    const updateExpr = new UpdateExpression()
    updateExpr.set('validated', 'true')
    const updateOptions = {
        condition: new FunctionExpression('attribute_exists', new AttributePath('email')),
    }
    await update(email, updateExpr, updateOptions)
}

export const resendForDate = async (date: string): Promise<void> => {
    const invites = await getForDate(date, sendEmailsMaxAttempts)
    logger.debug(`Unaccepted invites: ${JSON.stringify(invites)}`)
    for await (const invite of invites) {
        await sendAndSave(invite)
    }
}

/**
 * Get invites for particular date where sent_times < maxAttempts (notice: !<=)
 * that means invites have been already sent 1 time but have not been validated
 * @param date
 * @param maxAttempts
 */
export const getForDate = async (date: string, maxAttempts: number) => {
    const expr: AndExpression = {
        type: 'And',
        conditions: [
            {
                ...equals('false'),
                subject: 'validated',
            },
            {
                ...between(1, maxAttempts - 1),
                subject: 'sent_times',
            },
        ],
    }

    const filter: ConditionExpression = {
        subject: 'sent_at',
        ...equals(date),
    }

    return await getInvites(expr, filter)
}

/**
 * Get invites for period <= dateTime that have not been sent yet
 * @param dateTime
 */
const getUnsentInvitesUntil = async (dateTime: string) => {
    const expr: AndExpression = {
        type: 'And',
        conditions: [
            {
                ...equals('false'),
                subject: 'validated',
            },
            {
                ...equals(0),
                subject: 'sent_times',
            },
        ],
    }

    const filter: ConditionExpression = {
        subject: 'created_at',
        ...lessThanOrEqualTo(dateTime),
    }

    return await getInvites(expr, filter)
}

const sendAndSave = async (invite: Invite) => {
    try {
        await sendInvitationEmail(invite.email)
        await updateResentInvitation(invite.email)
    } catch (error) {
        logger.error(`Error occurred during sendAndSave invite email: ${invite.email}, errorMessage: ${error.message}`)
    }
}

export const updateResentInvitation = async (email: string) => {
    const updateExpr = new UpdateExpression()
    updateExpr.add('sent_times', 1)
    updateExpr.set('sent_at', toShortDate(new Date()))
    await update(email, updateExpr)
}

const initialDelayMinutes = +property('SEND_FIRST_EMAIL_DELAY_MINUTES')
export const sendFirstInvites = async () => {
    let dateTimeStr: string
    try {
        const dateTime = new Date()
        dateTime.setMinutes(new Date().getMinutes() - initialDelayMinutes)
        dateTimeStr = toDateTime(dateTime)
        const invites = await getUnsentInvitesUntil(dateTimeStr)
        logger.debug(`First invites found: ${JSON.stringify(invites)}`)
        await Promise.all(invites.map(async (invite) => await sendAndSave(invite)))
    } catch (error) {
        logger.error(
            `Error occurred during sending first invite for period: ${dateTimeStr}-${toDateTime(
                new Date(),
            )}, errorMessage: ${error.message}`,
        )
    }
}

const periodDays = +property('RESEND_EMAILS_PERIOD_DAYS')
export const resendUnacceptedInvites = async () => {
    let date: Date
    try {
        date = new Date()
        date.setDate(date.getDate() - periodDays)
        const dateStr = toShortDate(date)
        await resendForDate(dateStr)
    } catch (error) {
        logger.error(`Error occurred during resendInvites for date: ${date}, errorMessage: ${error.message}`)
    }
}
