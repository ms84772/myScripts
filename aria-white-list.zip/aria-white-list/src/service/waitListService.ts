import { batchRemove, get, put as saveEmail } from '../storage/waitListEmail'
import { IWaitListEmail } from '../types'
import { toWaitListEmail, toWaitListEmailDto } from '../transformer'
import logger from '@nmg/osp-backend-utils/logger'
import { toShortDate } from '../utils'
import { WhiteListDetails } from '../storage/whiteListDetails'

export const saveToWaitList = async (waitListEmailDto: IWaitListEmail): Promise<IWaitListEmail> => {
    logger.debug(`Save email ${waitListEmailDto.email} to wait list`)
    const toSave = toWaitListEmail(waitListEmailDto)
    toSave.created_at = toShortDate(new Date())
    const saved = await saveEmail(toSave)
    logger.debug(`Email ${waitListEmailDto.email} was saved in wait list`)
    return toWaitListEmailDto(saved)
}

export const emailExists = async (email): Promise<boolean> => {
    const found = await get(email)
    return found != undefined
}

export const removeFromWaitList = async (details: WhiteListDetails[]): Promise<void> => {
    const emails = details.map((i) => i.email)
    logger.debug(`Remove emails ${emails} from wait list`)
    await batchRemove(emails)
}
