cat /Users/msahagun1/showbanner/superman-logo-013.txt
echo ""

