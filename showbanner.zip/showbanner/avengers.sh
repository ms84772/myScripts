cat /Users/msahagun1/showbanner/avengerslogo.txt
echo ""

