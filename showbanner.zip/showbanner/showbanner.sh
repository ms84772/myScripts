d=`date +"%w"`
if [ $d == 1 ];then
	cmdo=/Users/msahagun1/showbanner/avengers.sh
fi
if [ $d == 2 ];then
	cmdo=/Users/msahagun1/showbanner/batman.sh
fi
if [ $d == 3 ];then
	cmdo=/Users/msahagun1/showbanner/capitanamerica.sh
fi
if [ $d == 4 ];then
	cmdo=/Users/msahagun1/showbanner/ironman.sh
fi
if [ $d == 5 ];then
	cmdo=/Users/msahagun1/showbanner/spiderman.sh
fi
if [ $d == 6 ];then
	cmdo=/Users/msahagun1/showbanner/superman.sh
fi
if [ $d == 0 ];then
	cmdo=/Users/msahagun1/showbanner/deadpool.sh
fi
$cmdo

