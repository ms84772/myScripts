cat /Users/msahagun1/showbanner/spidermanlogo.txt
echo ""

