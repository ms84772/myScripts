cat /Users/msahagun1/showbanner/deadpoollogo.txt
echo ""

