cat /Users/msahagun1/showbanner/capitanamericalogo.txt
echo ""

