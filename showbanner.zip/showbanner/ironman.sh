cat /Users/msahagun1/showbanner/ironmanlogo.txt
echo ""

