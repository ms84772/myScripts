#./batman.sh
/Users/msahagun1/showbanner/showbanner.sh
echo "=============================================================================="
echo "Welcome ${USER}"

